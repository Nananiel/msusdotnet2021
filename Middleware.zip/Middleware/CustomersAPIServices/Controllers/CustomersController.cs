﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CustomersAPIServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        // GET: api/Customers
        /*
        [HttpGet]
        [Authorize]
        public IEnumerable<string> Get()
        {
            return new string[] { "Value1", "Value2" };
        }
        */

        [HttpGet, Authorize]
        public IEnumerable<Model.CustomerModel> Get()
        {
            return Model.CustomerData.list;
        }

        // GET: api/Customers/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            foreach(var x in Model.CustomerData.list)
            {
                if (x.EmpID == id)
                    return x.EmpName;
            }
            return "Not Found";
        }
    }
}
