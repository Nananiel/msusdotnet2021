﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomersAPIServices.Model
{
    public static class CustomerData
    {
        public static IEnumerable<CustomerModel> list = new List<CustomerModel>
        {
            new CustomerModel()
            {
                EmpID = 1,
                EmpName = "Sourabh",
                EmpSalary = 50000
            },
            new CustomerModel()
            {
                EmpID = 2,
                EmpName = "Shaili",
                EmpSalary = 60000
            },
            new CustomerModel()
            {
                EmpID = 3,
                EmpName = "Saloni",
                EmpSalary = 55000
            }
        };
    }
}
