﻿using GraphQL;
using GraphQL.Types;
using PayrollEmployeeAPI.GraphqlTypes;
using PayrollEmployeeAPI.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayrollEmployeeAPI.GrahpqlSchemas
{
    public class AppQuery : ObjectGraphType
    {
        public AppQuery(IEmployeeRepo repository)
        {
            Name = "EmployeeQuery";
            Field<EmployeeType>(
                "employeeById",
                arguments: new QueryArguments(new QueryArgument<LongGraphType> { Name = "employeeId" }),
                resolve: context => repository.GetEmployeeById(context.GetArgument<long>("employeeId"))
                );
            Field<ListGraphType<EmployeeType>>(
               "employees",
               resolve: context => repository.GetAllEmployees()
           );
        }
    }
}
