﻿using System;

namespace Microservice.PoC.ClientService.Models
{
    public class Client
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public int ClientAge { get; set; }
        public string Remarks { get; set; }
    }
}
