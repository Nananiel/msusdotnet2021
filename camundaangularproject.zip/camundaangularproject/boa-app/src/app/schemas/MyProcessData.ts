export class MyProcessData {

  constructor(
    public firstName: string,
    public lastName: string,
    public approved: boolean
  ) {  }

}
