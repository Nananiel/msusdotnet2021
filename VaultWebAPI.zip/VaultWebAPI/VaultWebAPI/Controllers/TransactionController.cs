﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using VaultWebAPI.Models;
using VaultWebAPI.Repositories;
using Transaction = VaultWebAPI.Models.Transaction;

namespace VaultWebAPI.Controllers
{
    [ApiVersion("1")]
    [ApiVersion("2")]
    [Route("api/v{version:apiVersion}/[controller]")]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionRepo _tranRepository;

        //dependency injection
        public TransactionController(ITransactionRepo transactionRepository)
        {
            this._tranRepository = transactionRepository;
        }



        // GET: api/Transaction
        [MapToApiVersion("1")]
        [Route("Transactions")]
        [HttpGet]
        public IActionResult Get()
        {
            var transactions = this._tranRepository.GetAllTransactions();
            return new OkObjectResult(transactions);
        }

        // POST: api/Employee
        [HttpPost]
        public IActionResult Post([FromBody] Transaction transaction)
        {
            using (var scope = new TransactionScope())
            {
                _tranRepository.AddTransaction(transaction);
                scope.Complete();
                return CreatedAtAction(nameof(Get), new { id = transaction.TransactionId},transaction);
            }
        }

        
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            _tranRepository.DeleteTransaction(id);
            return new OkResult();
        }
    }
}
