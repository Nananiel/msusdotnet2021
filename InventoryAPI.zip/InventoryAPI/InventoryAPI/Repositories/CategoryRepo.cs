﻿using InventoryAPI.Contexts;
using InventoryAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.Repositories
{
    public class CategoryRepo : ICategoryRepo
    {
        private InventoryContext _dbContext;
        public CategoryRepo(InventoryContext dbContext)
        {
            _dbContext = dbContext;
        }

        public Category  AddCategory(Category category)
        {
            _dbContext.Add(category);
            Save();
            return category;
        }

        public void DeleteCategoryById(long categoryId)
        {
            var category = _dbContext.Categories.Find(categoryId);
            _dbContext.Categories.Remove(category);
            Save();
        }

        public IEnumerable<Category> GetAllCategories()
        {
            var categories = _dbContext.Categories.Include(catalog => catalog.ProductList).ToList();

            return categories;
        }

        public Category GetCategoryById(long categoryId)
        {
            var category = _dbContext.Categories.Include(c => c.ProductList)
               .FirstOrDefault(x => x.CategoryId == categoryId);

            return category;
        }

        public Category UpdateCategoryById(Category category)
        {
            _dbContext.Entry(category).State = EntityState.Modified;
            Save();
            return category;
        }


        public void Save()
        {
            _dbContext.SaveChanges();
        }
    }
}
