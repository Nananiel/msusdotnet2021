﻿using GraphQL.Types;
using InventoryAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.GraphqlTypes
{
    public class ProductType:ObjectGraphType<Product>
    {

      public  ProductType()
        {
            Name = "Product";
            Field(_ => _.ProductId).Description("Product Id.");
            Field(_ => _.ProductName.ModelNo).Description
           ("Model No");
            Field(_ => _.ProductName.Description).Description
          ("Description");
            Field(_ => _.ProductName.Brand).Description
           ("Brand");
            Field(_ => _.ProductName.StarRating).Description
           ("Star Rating");
        

        }
    }
}
