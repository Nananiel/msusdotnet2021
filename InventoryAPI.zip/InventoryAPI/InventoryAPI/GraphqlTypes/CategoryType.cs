﻿using GraphQL.Types;
using InventoryAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.GraphqlTypes
{
    public class CategoryType:ObjectGraphType<Category>
    {
        public CategoryType()
        {
            Name = "Category";
            Field(_ => _.CategoryId).Description("Category Id.");
            Field(_ => _.CategoryName).Description("Category Name");
        }
    }
}
