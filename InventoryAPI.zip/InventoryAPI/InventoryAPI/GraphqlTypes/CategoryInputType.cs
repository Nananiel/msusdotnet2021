﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.GraphqlTypes
{
    public class CategoryInputType:InputObjectGraphType
    {

        public CategoryInputType()
        {
            Name = "categoryInput";            
            Field<NonNullGraphType<StringGraphType>>("CategoryName");
        }
    }
}
