﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.GraphqlTypes
{
    public class ProductInputType:InputObjectGraphType
    {
        public ProductInputType()
        {
            Name = "productInput";
            Field<NonNullGraphType<NameInputType>>("ProductName");
            Field<NonNullGraphType<IntGraphType>>("ProductType");
       
        }
    }
}
