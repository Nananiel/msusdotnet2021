﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.Models
{
   public  enum ProductType { Regular, Seasonal}
    public class Product
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public long ProductId { get; set; }
        public Name ProductName { get; set; }

        public ProductType ProductType { get; set; }

        [ForeignKey("Category")]
        public long CategoryIdRef { get; set; }
        public Category Category { get; set; }
    }
}
