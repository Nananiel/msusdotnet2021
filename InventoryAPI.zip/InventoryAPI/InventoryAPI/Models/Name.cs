﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.Models
{
    [Owned]
    public class Name
    {
        public String ModelNo { get; set; }
        public String Description { get; set; }
        public String Brand { get; set; }
        public String StarRating { get; set; }
    }
}
