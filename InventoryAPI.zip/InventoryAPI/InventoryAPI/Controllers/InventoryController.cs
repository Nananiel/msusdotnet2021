﻿using InventoryAPI.Models;
using InventoryAPI.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;

namespace InventoryAPI.Controllers
{
    // [Route("api/[controller]")]
    [ApiController]
    [ApiVersion("1")]
    [ApiVersion("2")]
    [Route("api/v{version:apiVersion}/[controller]")]
    public class InventoryController : ControllerBase
    {

        private readonly ICategoryRepo _categoryRepository;


        public InventoryController(ICategoryRepo categoryRepository)
        {
            this._categoryRepository = categoryRepository;
        }



        // GET: api/Category
       [MapToApiVersion("1")]
        [Route("Inventories")]
        [HttpGet]
        public IActionResult GetV1()
        {
            var categories = this._categoryRepository.GetAllCategories();
            return new OkObjectResult(categories);
        }

        [MapToApiVersion("2")]
        [Route("Inventoriesv2")]
        [HttpGet]
        public IActionResult GetV2()
        {
            var categories = this._categoryRepository.GetAllCategories();
            return new OkObjectResult(categories);
        }

        // GET: api/Catalog/5
        [HttpGet("{id}", Name = "Get")]
        public IActionResult Get(long id)
        {
            var category = this._categoryRepository.GetCategoryById(id);
            return new OkObjectResult(category);
        }

        // POST: api/Catalog
        [HttpPost]
        public IActionResult Post([FromBody] Category category)
        {
            using (var scope = new TransactionScope())
            {
                _categoryRepository.AddCategory(category);
                scope.Complete();
                return CreatedAtAction(nameof(Get), new { id = category.CategoryId }, category);
            }
        }

        // PUT: api/Catalog/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Category category)
        {
            if (category != null)
            {
                using (var scope = new TransactionScope())
                {
                    _categoryRepository.UpdateCategoryById(category);
                    scope.Complete();
                    return new OkResult();
                }
            }
            return new NoContentResult();
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            _categoryRepository.DeleteCategoryById(id);
            return new OkResult();
        }
    }
}
