﻿using InventoryAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.Contexts
{
    public class InventoryContext:DbContext
    {

        public InventoryContext(DbContextOptions<InventoryContext> options) : base(options)
        {
            this.Database.EnsureCreated();
        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>()
       .HasMany(c => c.ProductList)
       .WithOne(e => e.Category);
        }
    }
}
