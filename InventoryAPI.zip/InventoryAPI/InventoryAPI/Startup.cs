using GraphQL.Server;
using GraphQL.Server.Ui.Playground;
using InventoryAPI.Contexts;
using InventoryAPI.Repositories;
using InventoryAPI.Schemas;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddDbContext<InventoryContext>(o => o.UseSqlServer(Configuration.GetConnectionString("InventoryDBConnString")));
            services.AddApiVersioning(); // just add this
            services.AddScoped<GraphqlProvider>();
            services.AddGraphQL()
               .AddSystemTextJson()
               .AddGraphTypes(typeof(GraphqlProvider), ServiceLifetime.Scoped);


            #region Swagger
            services.AddSwaggerGen(config =>
            {
                var titleBase = "Inventory API";
                var description = "This is a Web API for Movies operations";
                var TermsOfService = new Uri("https://test.com/user/eswari/");
                var License = new OpenApiLicense()
                {
                    Name = "RPS"
                };
                var Contact = new OpenApiContact()
                {
                    Name = "Parameswari",
                    Email = "parameswaribala@gmail.com",
                    Url = new Uri("https://eswaribala.blog/")
                };

                config.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = titleBase + " v1",
                    Description = description,
                    TermsOfService = TermsOfService,
                    License = License,
                    Contact = Contact
                });

                config.SwaggerDoc("v2", new OpenApiInfo
                {
                    Version = "v2",
                    Title = titleBase + " v2",
                    Description = description,
                    TermsOfService = TermsOfService,
                    License = License,
                    Contact = Contact
                });

            });
            #endregion
            services.AddTransient<ICategoryRepo,CategoryRepo>();
            services.AddControllers().AddNewtonsoftJson(options =>
    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            #region Swagger
            app.UseSwagger();

            app.UseSwaggerUI(config =>
            {
               // config.SwaggerEndpoint("/swagger/v1/swagger.json", "Inventory API v1");
               // config.SwaggerEndpoint("/swagger/v2/swagger.json", "Inventory API  v2");
                //config.SwaggerEndpoint($"/swagger/v1/swagger.json", "Inventory API");

                config.SwaggerEndpoint($"/swagger/v1/swagger.json", $"v1");
            });
            // Enable middleware to serve generated Swagger as a JSON endpoint.
            //app.UseSwagger();
            //app.UseSwaggerUI(c =>
            //{
            //    c.SwaggerEndpoint("v1/swagger.json", "MyAPI V1");
            //});
            #endregion
            app.UseGraphQL<GraphqlProvider>();
            app.UseGraphQLPlayground(options: new GraphQLPlaygroundOptions());
        }
    }
}
