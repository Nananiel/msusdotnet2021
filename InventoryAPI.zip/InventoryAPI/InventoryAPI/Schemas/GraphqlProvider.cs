﻿using GraphQL.Types;
using GraphQL.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.Schemas
{
    public class GraphqlProvider:Schema
    {
        public GraphqlProvider(IServiceProvider provider) : base(provider)
        {
            Query = provider.GetRequiredService<CategoryQuery>();
            Mutation = provider.GetRequiredService<CategoryMutation>();
          

        }
    }
}
