﻿using GraphQL;
using GraphQL.Types;
using InventoryAPI.GraphqlTypes;
using InventoryAPI.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryAPI.Schemas
{
    public class CategoryQuery:ObjectGraphType
    {

        public CategoryQuery(ICategoryRepo repository)
        {
            Name = "CategoryQuery";
            Field<CategoryType>(
                "categoryId",
                arguments: new QueryArguments(new QueryArgument<LongGraphType> 
                { Name = "categoryId" }),
                resolve: context => repository
                .GetCategoryById(context.GetArgument<long>("categoryId"))
                );
            Field<ListGraphType<CategoryType>>(
               "categories",
               resolve: context => repository.GetAllCategories()
           );
        }
    }
}
